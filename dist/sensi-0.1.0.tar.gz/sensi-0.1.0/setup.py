# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['sensi', 'sensi.database', 'sensi.resources']

package_data = \
{'': ['*'],
 'sensi.resources': ['nltk_data/corpora/*',
                     'nltk_data/corpora/stopwords/*',
                     'nltk_data/tokenizers/*',
                     'nltk_data/tokenizers/punkt/*',
                     'nltk_data/tokenizers/punkt/PY3/*']}

install_requires = \
['SQLAlchemy>=1.4.40,<2.0.0',
 'Sastrawi>=1.0.1,<2.0.0',
 'nltk>=3.7,<4.0',
 'numpy>=1.23.2,<2.0.0',
 'pandas>=1.4.3,<2.0.0']

setup_kwargs = {
    'name': 'sensi',
    'version': '0.1.0',
    'description': 'analisis sentimen bahasa Indonesia menggunakan Naive-Bayes',
    'long_description': 'None',
    'author': 'Ghazy',
    'author_email': '32423204+GazDuckington@users.noreply.github.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
